#version 150
#define HEIGHT_BIT 13
#define MAX_BIT 10
#define ADD_OFFSET 4095
#define DEFAULT_OFFSET 10
#define SHADER_VERSION 3
#moj_import <fog.glsl>
#if SHADER_VERSION >= 3
#moj_import <dynamictransforms.glsl>
#moj_import <projection.glsl>
#moj_import <globals.glsl>
out float sphericalVertexDistance;out float cylindricalVertexDistance;
#else
uniform mat4 ProjMat;uniform mat4 ModelViewMat;uniform int FogShape;out float vertexDistance;uniform vec2 ScreenSize;uniform float GameTime;
#endif
in vec3 Position;in vec4 Color;in vec2 UV0;in ivec2 UV2;uniform sampler2D Sampler0;uniform sampler2D Sampler2;uniform vec3 ChunkOffset;out vec4 vertexColor;out vec2 texCoord0;out float applyColor;bool range(float t, float m1, float m2) {return t >= m1 && t <= m2;}bool range(vec2 t, vec2 m1, vec2 m2) {return range(t.x, m1.x, m2.x) && range(t.y, m1.y, m2.y);}bool range(vec3 t, vec3 m1, vec3 m2) {return range(t.x, m1.x, m2.x) && range(t.y, m1.y, m2.y) && range(t.z, m1.z, m2.z);}bool checkElement(float z) {if (z == 0) return true; else if (z == 1000) return true; else if (z == -90) return true; else if (z == 2800) return true; return false;}float fogDistance(vec3 pos, int shape) {if (shape == 0) {return length(pos);} else {float distXZ = length(pos.xz);float distY = abs(pos.y);return max(distXZ, distY);}}/* ROOTLINE_PREFIX_EFFECTS_V4 */
float rootlineRandom(float seed) {
return fract(sin(seed * 12.9898) * 43758.5453);
}

vec2 rootlineCorner(float vertexId) {
if (vertexId < 0.5) return vec2(-1.0, -1.0);
if (vertexId < 1.5) return vec2(-1.0, 1.0);
if (vertexId < 2.5) return vec2(1.0, 1.0);
return vec2(1.0, -1.0);
}

void rootlineApplyPrefixEffect(inout vec3 pos, inout vec4 outputColor) {
ivec3 packed = ivec3(Color.rgb * 255.0 + vec3(0.5));
int effect = packed.g & 15;
bool encoded = (packed.r & 15) == 13 && (packed.b & 15) == 10
&& effect >= 1 && effect <= 8;
if (!encoded) return;

ivec3 high = packed & ivec3(240);
ivec3 restored = high + high / 16;
vec3 visible = vec3(restored) / 255.0;
vec4 light = texelFetch(Sampler2, UV2 / 16, 0);
outputColor = vec4(visible, Color.a) * light;

float vertexId = mod(float(gl_VertexID), 4.0);
float charId = floor(Position.x / 6.0);
float time = GameTime;

if (effect == 1) {
float frame = floor(time * 35200.0);
pos.x += (rootlineRandom(charId * 17.0 + frame * 1.3) - 0.5) * 2.3;
pos.y += (rootlineRandom(charId * 29.0 + frame * 2.1) - 0.5) * 2.3;
} else if (effect == 2) {
pos.y += sin(time * 12000.0 + Position.x * 0.75) * 1.1;
} else if (effect == 3) {
vec2 corner = rootlineCorner(vertexId);
float expansion = (sin(time * 1000.0) * 0.5 + 0.5) * 2.0;
pos.xy += corner * vec2(0.7, 1.0) * expansion;
} else if (effect == 4) {
vec2 corner = rootlineCorner(vertexId) * vec2(3.0, 4.0);
float angle = time * 1600.0 + charId * 0.55;
float sine = sin(angle);
float cosine = cos(angle);
vec2 rotated = mat2(cosine, -sine, sine, cosine) * corner;
pos.xy += rotated - corner;
} else if (effect == 5) {
float frame = floor(time * 30000.0);
float gate = rootlineRandom(frame * 0.1);
if (gate > 0.70) {
pos.x += (rootlineRandom(frame + charId * 3.0) - 0.5) * 4.0;
}
if (gate > 0.85) {
pos.y += (rootlineRandom(frame * 2.0 + charId) - 0.5) * 3.0;
}
} else if (effect == 6) {
float sweep = 1.0 - abs(fract(time * 500.0 + Position.x * 0.018) * 2.0 - 1.0);
vec3 gradient = mix(visible, mix(visible, vec3(1.0), 0.72), sweep);
outputColor = vec4(gradient, Color.a) * light;
} else if (effect == 7) {
float glow = 0.78 + 0.32 * (sin(time * 4500.0 + charId * 0.2) * 0.5 + 0.5);
vec3 neon = mix(visible, vec3(1.0), 0.28) * glow;
outputColor = vec4(neon, Color.a) * light;
} else if (effect == 8) {
float phase = mod(charId * 0.40 - time * 18000.0, 31.4159265359);
phase = min(phase, 6.28318530718);
pos.y -= (-cos(phase) * 0.5 + 0.5) * 2.2;
}
}
void main() {vec3 pos = Position;vec2 ui = ceil(2 / vec2(ProjMat[0][0], -ProjMat[1][1]));vec2 uiScreen = ui / ScreenSize;vec3 color = Color.xyz;applyColor = 0;vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);if (pos.y >= ui.y && ProjMat[3].x == -1) {int bit = int(pos.y) >> HEIGHT_BIT;if (((bit >> MAX_BIT) & 1) == 1) {int id = bit - (1 << MAX_BIT);pos.x -= 0.5 * ui.x;pos.y -= (bit << HEIGHT_BIT) + ADD_OFFSET + DEFAULT_OFFSET;float xGui = 0;float yGui = 0;float layer = 0;float opacity = 1;bool outline = false;int property = 0;switch (id) {case 1:break;case 2:xGui = ui.x * 35.0 / 100.0;yGui = ui.y * 100.0 / 100.0;break;case 3:xGui = ui.x * 50.0 / 100.0;break;case 4:xGui = ui.x * 65.0 / 100.0;yGui = ui.y * 100.0 / 100.0;break;}
#if SHADER_VERSION < 2
vertexColor = (checkElement(pos.z) && !outline) ? vec4(0) : Color * texelFetch(Sampler2, UV2 / 16, 0) * vec4(1, 1, 1, opacity);
#else
vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0) * vec4(1, 1, 1, opacity);
#endif
if ((property & 1) > 0) {pos.y += 4 * sin((GameTime * 1200 + pos.x / ui.x) * 3.1415 * 2);}if ((property & 2) > 0) {int hash = int(pos.x) * int(pos.y);float time = GameTime * 1200;hash = 31 * (hash + int(vertexColor.x + time));float r = float(hash % 224 + 32) / 255;hash = 31 * (hash + int(vertexColor.y + time));float g = float(hash % 224 + 32) / 255;hash = 31 * (hash + int(vertexColor.z + time));float b = float(hash % 224 + 32) / 255;float maxValue = max(max(r, g), b);vertexColor = vec4(pow(r / maxValue, 3), pow(g / maxValue, 3), pow(b / maxValue, 3), vertexColor.w);}if ((property & 4) > 0) {int hash = int(pos.x) * int(pos.y);float time = GameTime * 1200;hash = 31 * (hash + int(vertexColor.x + time));float r = vertexColor.x + float(hash % 64) / 255;hash = 31 * (hash + int(vertexColor.y + time));float g = vertexColor.y + float(hash % 64) / 255;hash = 31 * (hash + int(vertexColor.z + time));float b = vertexColor.z + float(hash % 64) / 255;vertexColor = vec4(r, g, b, vertexColor.w);}pos.x += xGui;pos.y += yGui;pos.z += layer;}} else {}rootlineApplyPrefixEffect(pos, vertexColor);
#if SHADER_VERSION >= 3
sphericalVertexDistance = fog_spherical_distance(pos);cylindricalVertexDistance = fog_cylindrical_distance(pos);
#else
vertexDistance = fogDistance(pos, FogShape);
#endif
texCoord0 = UV0;gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);}